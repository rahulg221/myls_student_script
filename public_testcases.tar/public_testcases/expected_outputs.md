# Example 1
               .	2	DIR	3	
              ..	3	DIR	3	
         .HIDDEN	1	REG	0	

# Example 2
               .	3	DIR	5	
              ..	3	DIR	3	
      secret.tar	1	REG	10240	.secret         
regular_file.txt	1	REG	40	This is the cont
    subdirectory	2	DIR	2	

# Example 3
               .	4	DIR	7	
              ..	3	DIR	3	
    readable.txt	1	REG	0	$
   executable.sh	1	REG	0	$
    inaccessible	2	DIR	unknown	
           mixed	2	DIR	4	
   writeable.txt	1	REG	0	$

# Example 4
               .    3   DIR 6   
              ..    3   DIR 3   
     message.txt    1   REG 6   hello 
       lorem.txt    1   REG 738 Lorem ipsum dolo
          subdir    2   DIR 3   
     message.png    1   REG 865  PNG        IHDR

